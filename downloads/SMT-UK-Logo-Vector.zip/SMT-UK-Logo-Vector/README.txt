SMT UK (Tautwire) logo, vector redraw, 15 Oct 2026
Redrawn as clean vector shapes from the SMT UK logo image supplied for Stand 15288 (no official vector was available online).
The circle, crosshair and T bar are exact geometry; S, M and TM use a Helvetica-style bold. Get SMT UK's sign-off before print.
SVG  - web, Illustrator, CorelDRAW, sign cutting
PDF  - print, opens in Illustrator
EPS  - print shops, Illustrator / CorelDRAW
PNG  - 4000 px transparent, for quick use
Black = for light backgrounds, White = for dark backgrounds. Aspect ratio 1010 : 436 (about 2.32 : 1).
